﻿namespace ZedGraph
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.connectToComPortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comPortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cb_selectComPort = new System.Windows.Forms.ToolStripComboBox();
            this.baudRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cb_selectBaudRate = new System.Windows.Forms.ToolStripComboBox();
            this.dataBitsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cb_selectDataBits = new System.Windows.Forms.ToolStripComboBox();
            this.stopBitsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cb_selectStopBits = new System.Windows.Forms.ToolStripComboBox();
            this.parityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cb_selectParity = new System.Windows.Forms.ToolStripComboBox();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitUtilityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chart1_timeDomain = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart1_frequencyDomain = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tb_dacFrequency = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_changeDacFrequency = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rb_stopPlot = new System.Windows.Forms.RadioButton();
            this.rb_startPlot = new System.Windows.Forms.RadioButton();
            this.btn_changeTrigger = new System.Windows.Forms.Button();
            this.cb_tiggerEdgeType = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_rawVoltage = new System.Windows.Forms.TextBox();
            this.tb_triggerConvertedVoltage = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_bufferLength = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_samplingFrequency = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_y2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_y1 = new System.Windows.Forms.Label();
            this.lbl_y2_y1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rb_magnitudeDecibel = new System.Windows.Forms.RadioButton();
            this.rb_magnitudeLinear = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rb_magnitudeResponse = new System.Windows.Forms.RadioButton();
            this.rb_phaseResponse = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_selectScale = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbl_frequency = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_freqIndex = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cb_timeScale = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1_timeDomain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1_frequencyDomain)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToComPortToolStripMenuItem,
            this.exitUtilityToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1293, 25);
            this.menuStrip1.TabIndex = 37;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // connectToComPortToolStripMenuItem
            // 
            this.connectToComPortToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comPortToolStripMenuItem,
            this.baudRateToolStripMenuItem,
            this.dataBitsToolStripMenuItem,
            this.stopBitsToolStripMenuItem,
            this.parityToolStripMenuItem,
            this.connectToolStripMenuItem,
            this.disconnectToolStripMenuItem});
            this.connectToComPortToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connectToComPortToolStripMenuItem.Name = "connectToComPortToolStripMenuItem";
            this.connectToComPortToolStripMenuItem.Size = new System.Drawing.Size(172, 21);
            this.connectToComPortToolStripMenuItem.Text = "Connect To External Device";
            // 
            // comPortToolStripMenuItem
            // 
            this.comPortToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cb_selectComPort});
            this.comPortToolStripMenuItem.Name = "comPortToolStripMenuItem";
            this.comPortToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.comPortToolStripMenuItem.Text = "Com Port";
            // 
            // cb_selectComPort
            // 
            this.cb_selectComPort.Name = "cb_selectComPort";
            this.cb_selectComPort.Size = new System.Drawing.Size(121, 23);
            this.cb_selectComPort.Click += new System.EventHandler(this.cb_selectComPort_Click);
            // 
            // baudRateToolStripMenuItem
            // 
            this.baudRateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cb_selectBaudRate});
            this.baudRateToolStripMenuItem.Name = "baudRateToolStripMenuItem";
            this.baudRateToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.baudRateToolStripMenuItem.Text = "Baud Rate";
            // 
            // cb_selectBaudRate
            // 
            this.cb_selectBaudRate.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "128000 ",
            "256000"});
            this.cb_selectBaudRate.Name = "cb_selectBaudRate";
            this.cb_selectBaudRate.Size = new System.Drawing.Size(121, 23);
            // 
            // dataBitsToolStripMenuItem
            // 
            this.dataBitsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cb_selectDataBits});
            this.dataBitsToolStripMenuItem.Name = "dataBitsToolStripMenuItem";
            this.dataBitsToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.dataBitsToolStripMenuItem.Text = "Data Bits";
            // 
            // cb_selectDataBits
            // 
            this.cb_selectDataBits.Items.AddRange(new object[] {
            "8",
            "9"});
            this.cb_selectDataBits.Name = "cb_selectDataBits";
            this.cb_selectDataBits.Size = new System.Drawing.Size(121, 23);
            // 
            // stopBitsToolStripMenuItem
            // 
            this.stopBitsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cb_selectStopBits});
            this.stopBitsToolStripMenuItem.Name = "stopBitsToolStripMenuItem";
            this.stopBitsToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.stopBitsToolStripMenuItem.Text = "Stop Bits";
            // 
            // cb_selectStopBits
            // 
            this.cb_selectStopBits.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cb_selectStopBits.Name = "cb_selectStopBits";
            this.cb_selectStopBits.Size = new System.Drawing.Size(121, 23);
            // 
            // parityToolStripMenuItem
            // 
            this.parityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cb_selectParity});
            this.parityToolStripMenuItem.Name = "parityToolStripMenuItem";
            this.parityToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.parityToolStripMenuItem.Text = "Parity";
            // 
            // cb_selectParity
            // 
            this.cb_selectParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cb_selectParity.Name = "cb_selectParity";
            this.cb_selectParity.Size = new System.Drawing.Size(121, 23);
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // exitUtilityToolStripMenuItem
            // 
            this.exitUtilityToolStripMenuItem.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitUtilityToolStripMenuItem.Name = "exitUtilityToolStripMenuItem";
            this.exitUtilityToolStripMenuItem.Size = new System.Drawing.Size(157, 21);
            this.exitUtilityToolStripMenuItem.Text = "Close Oscilloscope";
            this.exitUtilityToolStripMenuItem.Click += new System.EventHandler(this.exitUtilityToolStripMenuItem_Click);
            // 
            // chart1_timeDomain
            // 
            this.chart1_timeDomain.BackColor = System.Drawing.SystemColors.ControlDark;
            this.chart1_timeDomain.BackImageTransparentColor = System.Drawing.Color.Red;
            chartArea1.AxisX.LabelStyle.Format = "##0.#####";
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea1.AxisX.Title = "Time(s)";
            chartArea1.AxisY.LabelStyle.Format = "#.###";
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea1.AxisY.Title = "Amplitude(V)";
            chartArea1.BackColor = System.Drawing.Color.Black;
            chartArea1.CursorX.IsUserEnabled = true;
            chartArea1.CursorX.IsUserSelectionEnabled = true;
            chartArea1.CursorY.IsUserEnabled = true;
            chartArea1.CursorY.IsUserSelectionEnabled = true;
            chartArea1.Name = "ChartArea1";
            this.chart1_timeDomain.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1_timeDomain.Legends.Add(legend1);
            this.chart1_timeDomain.Location = new System.Drawing.Point(184, 42);
            this.chart1_timeDomain.Name = "chart1_timeDomain";
            series1.BorderColor = System.Drawing.Color.Yellow;
            series1.BorderWidth = 2;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Color = System.Drawing.Color.Yellow;
            series1.Legend = "Legend1";
            series1.MarkerSize = 6;
            series1.Name = "ch1_time";
            series2.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            series2.BorderWidth = 2;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.Red;
            series2.Legend = "Legend1";
            series2.Name = "TRIGGER";
            this.chart1_timeDomain.Series.Add(series1);
            this.chart1_timeDomain.Series.Add(series2);
            this.chart1_timeDomain.Size = new System.Drawing.Size(902, 331);
            this.chart1_timeDomain.TabIndex = 38;
            this.chart1_timeDomain.Text = "chart1_timeDomain";
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title1.Name = "Time Domain Plot";
            title1.Text = "Time Domain Plot";
            this.chart1_timeDomain.Titles.Add(title1);
            // 
            // chart1_frequencyDomain
            // 
            this.chart1_frequencyDomain.BackColor = System.Drawing.SystemColors.ControlDark;
            chartArea2.AxisX.LabelStyle.Format = "##.######";
            chartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea2.AxisX.Title = "Frequency(Hz)";
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea2.AxisY.Title = "Magnitude";
            chartArea2.BackColor = System.Drawing.Color.Black;
            chartArea2.CursorX.IsUserEnabled = true;
            chartArea2.CursorX.IsUserSelectionEnabled = true;
            chartArea2.CursorY.IsUserEnabled = true;
            chartArea2.CursorY.IsUserSelectionEnabled = true;
            chartArea2.Name = "ChartArea1";
            this.chart1_frequencyDomain.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1_frequencyDomain.Legends.Add(legend2);
            this.chart1_frequencyDomain.Location = new System.Drawing.Point(184, 381);
            this.chart1_frequencyDomain.Name = "chart1_frequencyDomain";
            series3.BorderColor = System.Drawing.Color.White;
            series3.BorderWidth = 2;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            series3.Legend = "Legend1";
            series3.MarkerSize = 7;
            series3.Name = "ch1_mag";
            series4.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            series4.BorderWidth = 2;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series4.Color = System.Drawing.Color.Lime;
            series4.Legend = "Legend1";
            series4.Name = "ch1_phase";
            this.chart1_frequencyDomain.Series.Add(series3);
            this.chart1_frequencyDomain.Series.Add(series4);
            this.chart1_frequencyDomain.Size = new System.Drawing.Size(902, 331);
            this.chart1_frequencyDomain.TabIndex = 39;
            this.chart1_frequencyDomain.Text = "chart1";
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title2.Name = "Title1";
            title2.Text = "Frequency Domain Plot";
            this.chart1_frequencyDomain.Titles.Add(title2);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBox1.Controls.Add(this.tb_dacFrequency);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.btn_changeDacFrequency);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.btn_changeTrigger);
            this.groupBox1.Controls.Add(this.cb_tiggerEdgeType);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_rawVoltage);
            this.groupBox1.Controls.Add(this.tb_triggerConvertedVoltage);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cb_bufferLength);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cb_samplingFrequency);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(1092, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(189, 670);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sample Control";
            // 
            // tb_dacFrequency
            // 
            this.tb_dacFrequency.Location = new System.Drawing.Point(7, 134);
            this.tb_dacFrequency.Name = "tb_dacFrequency";
            this.tb_dacFrequency.Size = new System.Drawing.Size(130, 26);
            this.tb_dacFrequency.TabIndex = 70;
            this.tb_dacFrequency.Text = "1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(143, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 20);
            this.label10.TabIndex = 69;
            this.label10.Text = "Hz";
            // 
            // btn_changeDacFrequency
            // 
            this.btn_changeDacFrequency.Location = new System.Drawing.Point(7, 166);
            this.btn_changeDacFrequency.Name = "btn_changeDacFrequency";
            this.btn_changeDacFrequency.Size = new System.Drawing.Size(168, 37);
            this.btn_changeDacFrequency.TabIndex = 68;
            this.btn_changeDacFrequency.Text = "Change DAC Freq";
            this.btn_changeDacFrequency.UseVisualStyleBackColor = true;
            this.btn_changeDacFrequency.Click += new System.EventHandler(this.Btn_changeDacFrequency_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 20);
            this.label9.TabIndex = 66;
            this.label9.Text = "DAC Frequency:";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox5.Controls.Add(this.rb_stopPlot);
            this.groupBox5.Controls.Add(this.rb_startPlot);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(10, 26);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(168, 72);
            this.groupBox5.TabIndex = 61;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Plot";
            // 
            // rb_stopPlot
            // 
            this.rb_stopPlot.AutoSize = true;
            this.rb_stopPlot.Checked = true;
            this.rb_stopPlot.Location = new System.Drawing.Point(11, 46);
            this.rb_stopPlot.Name = "rb_stopPlot";
            this.rb_stopPlot.Size = new System.Drawing.Size(89, 20);
            this.rb_stopPlot.TabIndex = 1;
            this.rb_stopPlot.TabStop = true;
            this.rb_stopPlot.Text = "Stop Plot";
            this.rb_stopPlot.UseVisualStyleBackColor = true;
            this.rb_stopPlot.CheckedChanged += new System.EventHandler(this.Rb_stopPlot_CheckedChanged);
            // 
            // rb_startPlot
            // 
            this.rb_startPlot.AutoSize = true;
            this.rb_startPlot.Location = new System.Drawing.Point(11, 21);
            this.rb_startPlot.Name = "rb_startPlot";
            this.rb_startPlot.Size = new System.Drawing.Size(89, 20);
            this.rb_startPlot.TabIndex = 0;
            this.rb_startPlot.Text = "Start Plot";
            this.rb_startPlot.UseVisualStyleBackColor = true;
            this.rb_startPlot.CheckedChanged += new System.EventHandler(this.Rb_startPlot_CheckedChanged);
            // 
            // btn_changeTrigger
            // 
            this.btn_changeTrigger.Location = new System.Drawing.Point(6, 419);
            this.btn_changeTrigger.Name = "btn_changeTrigger";
            this.btn_changeTrigger.Size = new System.Drawing.Size(168, 37);
            this.btn_changeTrigger.TabIndex = 60;
            this.btn_changeTrigger.Text = "Change Trigger";
            this.btn_changeTrigger.UseVisualStyleBackColor = true;
            this.btn_changeTrigger.Click += new System.EventHandler(this.Btn_changeTrigger_Click_1);
            // 
            // cb_tiggerEdgeType
            // 
            this.cb_tiggerEdgeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_tiggerEdgeType.FormattingEnabled = true;
            this.cb_tiggerEdgeType.Items.AddRange(new object[] {
            "Rising",
            "Falling",
            "Either"});
            this.cb_tiggerEdgeType.Location = new System.Drawing.Point(7, 506);
            this.cb_tiggerEdgeType.Name = "cb_tiggerEdgeType";
            this.cb_tiggerEdgeType.Size = new System.Drawing.Size(168, 28);
            this.cb_tiggerEdgeType.TabIndex = 59;
            this.cb_tiggerEdgeType.SelectedIndexChanged += new System.EventHandler(this.Cb_tiggerEdgeType_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 483);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 20);
            this.label5.TabIndex = 58;
            this.label5.Text = "Tigger Edge:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(70, 389);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 24);
            this.label4.TabIndex = 57;
            this.label4.Text = "V";
            // 
            // tb_rawVoltage
            // 
            this.tb_rawVoltage.Location = new System.Drawing.Point(95, 387);
            this.tb_rawVoltage.Name = "tb_rawVoltage";
            this.tb_rawVoltage.ReadOnly = true;
            this.tb_rawVoltage.Size = new System.Drawing.Size(79, 26);
            this.tb_rawVoltage.TabIndex = 56;
            this.tb_rawVoltage.Text = "32768";
            // 
            // tb_triggerConvertedVoltage
            // 
            this.tb_triggerConvertedVoltage.Location = new System.Drawing.Point(6, 387);
            this.tb_triggerConvertedVoltage.Name = "tb_triggerConvertedVoltage";
            this.tb_triggerConvertedVoltage.Size = new System.Drawing.Size(58, 26);
            this.tb_triggerConvertedVoltage.TabIndex = 54;
            this.tb_triggerConvertedVoltage.Text = "0.5";
            this.tb_triggerConvertedVoltage.TextChanged += new System.EventHandler(this.tb_triggerConvertedVoltage_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 359);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 20);
            this.label3.TabIndex = 53;
            this.label3.Text = "Tigger Raw Voltage:";
            // 
            // cb_bufferLength
            // 
            this.cb_bufferLength.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_bufferLength.FormattingEnabled = true;
            this.cb_bufferLength.Items.AddRange(new object[] {
            "64",
            "256",
            "512",
            "1024"});
            this.cb_bufferLength.Location = new System.Drawing.Point(7, 317);
            this.cb_bufferLength.Name = "cb_bufferLength";
            this.cb_bufferLength.Size = new System.Drawing.Size(107, 28);
            this.cb_bufferLength.TabIndex = 52;
            this.cb_bufferLength.SelectedIndexChanged += new System.EventHandler(this.cb_bufferLength_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 294);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 20);
            this.label2.TabIndex = 51;
            this.label2.Text = "Buffer Length:";
            // 
            // cb_samplingFrequency
            // 
            this.cb_samplingFrequency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_samplingFrequency.FormattingEnabled = true;
            this.cb_samplingFrequency.Items.AddRange(new object[] {
            "25 kHz",
            "100 kHz",
            "400 kHz",
            "10 MHz"});
            this.cb_samplingFrequency.Location = new System.Drawing.Point(10, 248);
            this.cb_samplingFrequency.Name = "cb_samplingFrequency";
            this.cb_samplingFrequency.Size = new System.Drawing.Size(168, 28);
            this.cb_samplingFrequency.TabIndex = 48;
            this.cb_samplingFrequency.SelectedIndexChanged += new System.EventHandler(this.cb_samplingFrequency_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "Timer Frequency:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 20);
            this.label6.TabIndex = 61;
            this.label6.Text = "Y2:";
            // 
            // lbl_y2
            // 
            this.lbl_y2.AutoSize = true;
            this.lbl_y2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_y2.Location = new System.Drawing.Point(48, 17);
            this.lbl_y2.Name = "lbl_y2";
            this.lbl_y2.Size = new System.Drawing.Size(36, 20);
            this.lbl_y2.TabIndex = 62;
            this.lbl_y2.Text = "Y1:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 20);
            this.label8.TabIndex = 64;
            this.label8.Text = "Y1:";
            // 
            // lbl_y1
            // 
            this.lbl_y1.AutoSize = true;
            this.lbl_y1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_y1.Location = new System.Drawing.Point(50, 45);
            this.lbl_y1.Name = "lbl_y1";
            this.lbl_y1.Size = new System.Drawing.Size(36, 20);
            this.lbl_y1.TabIndex = 63;
            this.lbl_y1.Text = "Y1:";
            // 
            // lbl_y2_y1
            // 
            this.lbl_y2_y1.AutoSize = true;
            this.lbl_y2_y1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_y2_y1.Location = new System.Drawing.Point(48, 76);
            this.lbl_y2_y1.Name = "lbl_y2_y1";
            this.lbl_y2_y1.Size = new System.Drawing.Size(64, 20);
            this.lbl_y2_y1.TabIndex = 66;
            this.lbl_y2_y1.Text = "Y2-Y1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 20);
            this.label11.TabIndex = 65;
            this.label11.Text = "∆Y:";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBox6.Controls.Add(this.rb_magnitudeDecibel);
            this.groupBox6.Controls.Add(this.rb_magnitudeLinear);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(10, 470);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(168, 87);
            this.groupBox6.TabIndex = 53;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Scale";
            // 
            // rb_magnitudeDecibel
            // 
            this.rb_magnitudeDecibel.AutoSize = true;
            this.rb_magnitudeDecibel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_magnitudeDecibel.Location = new System.Drawing.Point(9, 55);
            this.rb_magnitudeDecibel.Name = "rb_magnitudeDecibel";
            this.rb_magnitudeDecibel.Size = new System.Drawing.Size(80, 24);
            this.rb_magnitudeDecibel.TabIndex = 3;
            this.rb_magnitudeDecibel.Text = "Decibel";
            this.rb_magnitudeDecibel.UseVisualStyleBackColor = true;
            // 
            // rb_magnitudeLinear
            // 
            this.rb_magnitudeLinear.AutoSize = true;
            this.rb_magnitudeLinear.Checked = true;
            this.rb_magnitudeLinear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_magnitudeLinear.Location = new System.Drawing.Point(10, 25);
            this.rb_magnitudeLinear.Name = "rb_magnitudeLinear";
            this.rb_magnitudeLinear.Size = new System.Drawing.Size(71, 24);
            this.rb_magnitudeLinear.TabIndex = 2;
            this.rb_magnitudeLinear.TabStop = true;
            this.rb_magnitudeLinear.Text = "Linear";
            this.rb_magnitudeLinear.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.lbl_y2);
            this.groupBox7.Controls.Add(this.lbl_y1);
            this.groupBox7.Controls.Add(this.lbl_y2_y1);
            this.groupBox7.Controls.Add(this.label8);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Location = new System.Drawing.Point(949, 211);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(122, 100);
            this.groupBox7.TabIndex = 68;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Amplitude Readings";
            // 
            // rb_magnitudeResponse
            // 
            this.rb_magnitudeResponse.AutoSize = true;
            this.rb_magnitudeResponse.Checked = true;
            this.rb_magnitudeResponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_magnitudeResponse.Location = new System.Drawing.Point(8, 20);
            this.rb_magnitudeResponse.Name = "rb_magnitudeResponse";
            this.rb_magnitudeResponse.Size = new System.Drawing.Size(102, 24);
            this.rb_magnitudeResponse.TabIndex = 2;
            this.rb_magnitudeResponse.TabStop = true;
            this.rb_magnitudeResponse.Text = "Magnitude";
            this.rb_magnitudeResponse.UseVisualStyleBackColor = true;
            // 
            // rb_phaseResponse
            // 
            this.rb_phaseResponse.AutoSize = true;
            this.rb_phaseResponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_phaseResponse.Location = new System.Drawing.Point(10, 50);
            this.rb_phaseResponse.Name = "rb_phaseResponse";
            this.rb_phaseResponse.Size = new System.Drawing.Size(72, 24);
            this.rb_phaseResponse.TabIndex = 3;
            this.rb_phaseResponse.Text = "Phase";
            this.rb_phaseResponse.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBox2.Controls.Add(this.rb_phaseResponse);
            this.groupBox2.Controls.Add(this.rb_magnitudeResponse);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(10, 381);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(168, 83);
            this.groupBox2.TabIndex = 52;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Response Type";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 20);
            this.label7.TabIndex = 49;
            this.label7.Text = "Select Scale:";
            // 
            // cb_selectScale
            // 
            this.cb_selectScale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_selectScale.FormattingEnabled = true;
            this.cb_selectScale.Items.AddRange(new object[] {
            "0.5±(0.5/2)",
            "0.5±(0.5/8)",
            "0.5±(0.5/32)",
            "0.5±(0.5/100)",
            "0-1"});
            this.cb_selectScale.Location = new System.Drawing.Point(10, 47);
            this.cb_selectScale.Name = "cb_selectScale";
            this.cb_selectScale.Size = new System.Drawing.Size(151, 28);
            this.cb_selectScale.TabIndex = 50;
            this.cb_selectScale.SelectedIndexChanged += new System.EventHandler(this.Cb_selectScale_SelectedIndexChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBox8.Controls.Add(this.cb_selectScale);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(10, 42);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(168, 92);
            this.groupBox8.TabIndex = 70;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Amplitude Scaling";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.lbl_freqIndex);
            this.groupBox3.Controls.Add(this.lbl_frequency);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Location = new System.Drawing.Point(929, 548);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(142, 111);
            this.groupBox3.TabIndex = 71;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Frequency Readings";
            // 
            // lbl_frequency
            // 
            this.lbl_frequency.AutoSize = true;
            this.lbl_frequency.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_frequency.Location = new System.Drawing.Point(68, 16);
            this.lbl_frequency.Name = "lbl_frequency";
            this.lbl_frequency.Size = new System.Drawing.Size(64, 20);
            this.lbl_frequency.TabIndex = 66;
            this.lbl_frequency.Text = "Y2-Y1:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 20);
            this.label17.TabIndex = 65;
            this.label17.Text = "F(Hz):";
            // 
            // lbl_freqIndex
            // 
            this.lbl_freqIndex.AutoSize = true;
            this.lbl_freqIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_freqIndex.Location = new System.Drawing.Point(68, 48);
            this.lbl_freqIndex.Name = "lbl_freqIndex";
            this.lbl_freqIndex.Size = new System.Drawing.Size(64, 20);
            this.lbl_freqIndex.TabIndex = 67;
            this.lbl_freqIndex.Text = "Y2-Y1:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 48);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 20);
            this.label13.TabIndex = 68;
            this.label13.Text = "Index:";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBox4.Controls.Add(this.cb_timeScale);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(10, 140);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(168, 92);
            this.groupBox4.TabIndex = 71;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Time Scaling";
            // 
            // cb_timeScale
            // 
            this.cb_timeScale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_timeScale.FormattingEnabled = true;
            this.cb_timeScale.Items.AddRange(new object[] {
            "0.5",
            "0.25",
            "0.125",
            "1"});
            this.cb_timeScale.Location = new System.Drawing.Point(10, 47);
            this.cb_timeScale.Name = "cb_timeScale";
            this.cb_timeScale.Size = new System.Drawing.Size(151, 28);
            this.cb_timeScale.TabIndex = 50;
            this.cb_timeScale.SelectedIndexChanged += new System.EventHandler(this.Cb_timeScale_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 20);
            this.label12.TabIndex = 49;
            this.label12.Text = "Select Scale:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1293, 724);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chart1_frequencyDomain);
            this.Controls.Add(this.chart1_timeDomain);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Digital Oscilloscope";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1_timeDomain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1_frequencyDomain)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem connectToComPortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comPortToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox cb_selectComPort;
        private System.Windows.Forms.ToolStripMenuItem baudRateToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox cb_selectBaudRate;
        private System.Windows.Forms.ToolStripMenuItem dataBitsToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox cb_selectDataBits;
        private System.Windows.Forms.ToolStripMenuItem stopBitsToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox cb_selectStopBits;
        private System.Windows.Forms.ToolStripMenuItem parityToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox cb_selectParity;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitUtilityToolStripMenuItem;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1_timeDomain;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1_frequencyDomain;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cb_samplingFrequency;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_triggerConvertedVoltage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_bufferLength;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_rawVoltage;
        private System.Windows.Forms.ComboBox cb_tiggerEdgeType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_changeTrigger;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_y2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_y1;
        private System.Windows.Forms.Label lbl_y2_y1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rb_stopPlot;
        private System.Windows.Forms.RadioButton rb_startPlot;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton rb_magnitudeDecibel;
        private System.Windows.Forms.RadioButton rb_magnitudeLinear;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rb_magnitudeResponse;
        private System.Windows.Forms.RadioButton rb_phaseResponse;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cb_selectScale;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_changeDacFrequency;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_dacFrequency;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_frequency;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_freqIndex;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cb_timeScale;
        private System.Windows.Forms.Label label12;
    }
}

