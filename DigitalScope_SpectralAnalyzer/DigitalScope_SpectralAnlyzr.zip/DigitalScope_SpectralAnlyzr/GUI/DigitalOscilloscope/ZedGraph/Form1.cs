﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace ZedGraph
{
    public partial class Form1 : Form
    {
        /****************** Variables to hold File Path **************************************/

        String rxData = String.Empty;


        private delegate void AddDataDelegate(string myString);
        private AddDataDelegate updateTimeChart;

        public Form1()
        {
            InitializeComponent();
            updateSerialDevices();
            serialPort1.ReceivedBytesThreshold = 1;
            cb_selectBaudRate.Text = "115200";
            cb_selectDataBits.Text = "8";
            cb_selectParity.Text = "None";
            cb_selectStopBits.Text = "1";
            cb_samplingFrequency.Text = "4 kHz";
            cb_tiggerEdgeType.Text = "Rising";
            cb_bufferLength.Text = "256";
            this.updateTimeChart = new AddDataDelegate(updateZedChart1);
            chart1_timeDomain.ChartAreas["ChartArea1"].AxisX.Title = "Time";
            chart1_timeDomain.ChartAreas["ChartArea1"].AxisY.Title = "Amplitude";

        }

        private void updateSerialDevices()
        {
            cb_selectComPort.Items.Clear();
            cb_selectComPort.Items.AddRange(SerialPort.GetPortNames());
        }

        private void updateZedChart1(string data)
        {
            try
            {
                data = parseResponse(data, "@", "!");
                string[] allSamples = data.Split(',');

                double Fs = getCurrentSamplingFrequency();
                double Ts = 1 / Fs;


                //define containers

                //voltage samples
                List<double> _channel1Amplitude = new List<double>();
                List<double> _channel1Time = new List<double>();

                //DFT
                List<double> _channel1FrequencyPositive = new List<double>();
                List<double> _channel1FrequencyNegative = new List<double>();

                List<double> _channel1Mag = new List<double>();
                List<double> _channel1MagnitudePositive = new List<double>();
                List<double> _channel1MagitudeNegative = new List<double>();
                List<double> _channel1MagnitudeSearch = new List<double>();

                List<double> _channel1Phase = new List<double>();

                List<double> _freqList = new List<double>();


                //store amplitude and time values
                double timeStart = 0;
                double timeIncrement = Ts;
                for (int i = 0; i < (allSamples.Length - 1); i++)
                {
                    double val = Convert.ToDouble(allSamples[i]);
                    val = rawReadingToVoltage(val);
                    _channel1Amplitude.Add(val);
                    _channel1Time.Add(timeStart); //store time values
                    timeStart += Ts; 
                }


                //calculate positive frequency values
                double harmonic = Fs / _channel1Amplitude.Count;
				
                //double _freqIncrements = 0;
                int nCount = _channel1Amplitude.Count / 2;
                for (int i = 0; i < nCount; i++)
                {
                    _channel1FrequencyPositive.Add(i * harmonic);
                }

                //calacute negative frequency values
                int temp1 = nCount-1;
                for (int i = temp1; i > 0; i--)
                {
                    _channel1FrequencyNegative.Add( ( -1 * _channel1FrequencyPositive.ElementAt(i)) );
                }


                //calculate values for frequency domain chart
                double _maxVal = 0.0;
                int _maxValIndex = 0;
                for (int n = 0; n < (allSamples.Length - 1); n++)
                {
                    double dftReal = 0.0;
                    double dftImag = 0.0;
                    for (int k = 0; k < (allSamples.Length - 1); k++)
                    {
                        dftReal += _channel1Amplitude.ElementAt(k) * Math.Cos((2 * Math.PI * n * k) /  (double)_channel1Amplitude.Count); //real 
                        dftImag += _channel1Amplitude.ElementAt(k) * Math.Sin((2 * Math.PI * n * k) / (double)_channel1Amplitude.Count); //imaginay
                    }

                    double tempMag = (dftReal * dftReal) + (dftImag * dftImag);
                    _channel1Mag.Add(tempMag);
                    _channel1Phase.Add((Math.Atan(dftImag / dftReal) * ((double)180 / Math.PI)));
					
                    if( (n > 5) && (n < (allSamples.Length/2)) )
                    {
                        if (_maxVal < tempMag)
                        {
                            _maxVal = tempMag;
                            _maxValIndex = n;
                        }
                    }
                }

                //remove dc
                //_channel1Mag.RemoveAt(0);
                //_channel1Mag.Insert(0, 0);


                //calculate absolute magnitude values
                for (int i = 0; i < (_channel1Mag.Count / 2); i++)
                {
                    double temp = _channel1Mag.ElementAt(i);
                    temp = Math.Abs(temp);
                    _channel1MagnitudePositive.Add(temp);
                }
                

                //store values for magnitude response negative 
                int temp2 = _channel1MagnitudePositive.Count - 1;
                for (int i = temp2; i > 0; i--)
                {
                    _channel1MagitudeNegative.Add(_channel1Mag.ElementAt(i));
                }


                //clear chart
                clearCharts();


                //display peak to peak voltage
                lbl_y2.Text = _channel1Amplitude.Max().ToString("##0.000");
                lbl_y1.Text = _channel1Amplitude.Min().ToString("##0.000");
                lbl_y2_y1.Text = (_channel1Amplitude.Max() - _channel1Amplitude.Min()).ToString("##0.000");

                //display frequency val
                //double signalFreq = Fs / Convert.ToDouble(cb_bufferLength.Text); //_channel1FrequencyPositive.ElementAt(_maxValIndex).ToString();
                //double signalFreq = (99840) / Convert.ToDouble(cb_bufferLength.Text);
                //double signalFreq = _channel1FrequencyPositive.ElementAt(_maxValIndex);
                //signalFreq = signalFreq * _maxValIndex;
                //lbl_frequency.Text = signalFreq.ToString();
                //lbl_frequency.Text = signalFreq.ToString();
                //lbl_frequency.Text = _maxValIndex.ToString();
                lbl_freqIndex.Text = _maxValIndex.ToString();
                double bufLen = Convert.ToDouble(cb_bufferLength.Text);
                //if (Fs == 51200)
                //{
                    lbl_frequency.Text = ((_maxValIndex * ((Fs) / bufLen)) - 200).ToString();
                //}
                //lbl_frequency.Text = (_maxValIndex * ((Fs) / bufLen)).ToString();
                //lbl_xAxisMinn.Text = chart1_timeDomain.ChartAreas[0].AxisX.Maximum.ToString();


                //plot ampitude vs time chart
                for (int i = 0; i < _channel1Amplitude.Count; i++)
                {
                    //chart1_timeDomain.Series["TRIGGER"].Points.AddXY(_channel1Time.ElementAt(i),Convert.ToDouble(tb_triggerConvertedVoltage.Text));//plot trigger
                    //chart1_timeDomain.Series["ch1_time"].Points.AddXY(_channel1Time.ElementAt(i), _channel1Amplitude.ElementAt(i)); //plot time response
                    chart1_timeDomain.Series["ch1_time"].Points.AddY( _channel1Amplitude.ElementAt(i)); //plot time response
                    chart1_timeDomain.Series["TRIGGER"].Points.AddY(Convert.ToDouble(tb_triggerConvertedVoltage.Text));//plot trigger
                }


                //plot spectrum
                if (rb_magnitudeResponse.Checked == true)
                {
                    
                    for (int i = 0; i < _channel1MagitudeNegative.Count; i++)
                    {
                        if (rb_magnitudeDecibel.Checked == true)
                        {
                            chart1_frequencyDomain.Series["ch1_mag"].Points.AddXY(_channel1FrequencyNegative.ElementAt(i), (20 * Math.Log10(_channel1MagitudeNegative.ElementAt(i)))); //plot magnitude response
                        }
                        else
                        {
                            chart1_frequencyDomain.Series["ch1_mag"].Points.AddXY(_channel1FrequencyNegative.ElementAt(i), _channel1MagitudeNegative.ElementAt(i)); //plot magnitude response
                            //chart1_frequencyDomain.Series["ch1_mag"].Points.AddY( _channel1MagitudeNegative.ElementAt(i)); //plot magnitude response

                        }

                    }
                   

                    //plot right half 
                    for (int i = 0; i < _channel1MagnitudePositive.Count; i++)
                    {

                        if (rb_magnitudeDecibel.Checked == true)
                        {
                            chart1_frequencyDomain.Series["ch1_mag"].Points.AddXY(_channel1FrequencyPositive.ElementAt(i), (20 * Math.Log10(_channel1MagnitudePositive.ElementAt(i)))); //plot magnitude response
                        }
                        else
                        {
                            chart1_frequencyDomain.Series["ch1_mag"].Points.AddXY(_channel1FrequencyPositive.ElementAt(i), _channel1MagnitudePositive.ElementAt(i)); //plot magnitude response
                        }
                        
                    }
                    
                }
                else
                {
                    //pllot phase
                    for (int i = 0; i < _channel1Phase.Count; i++)
                    {
                        chart1_frequencyDomain.Series["ch1_phase"].Points.AddY(_channel1Phase.ElementAt(i)); //plot magnitude response
                    }
                }

                rxData = String.Empty;

                if (rb_startPlot.Checked == true)
                {
                    serialPort1.Write("g@");
                }
                else
                {
                    clearCharts();
                }

            }
            catch (Exception e)
            {
                rxData = String.Empty;

                if (rb_startPlot.Checked == true)
                {
                    serialPort1.Write("g@");
                }
                else
                {
                    clearCharts();
                }
            }
        }


        private void updateRxString(object sender, EventArgs e)
        {
            //tb_serialReceive.Text = rxData;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            rxData += sp.ReadExisting();

            //tb_serialReceive.Invoke(new EventHandler(updateRxString) );

            //check for the last bit
            if (rxData[rxData.Length - 1] == '!')
            {
                chart1_timeDomain.Invoke(this.updateTimeChart, new object[] { rxData });
            }
        }

        private void exitUtilityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Application.Exit();
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openSerialPort();
            MessageBox.Show("Connected");
        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            MessageBox.Show("Disconnected");
        }

        private string parseResponse(string dataPacket, string token1, string token2)
        {
            int token1Index = dataPacket.IndexOf(token1);
            int token2Index = dataPacket.IndexOf(token2);
            string result = dataPacket.Substring(token1Index + 1, token2Index - token1Index - 1);
            return result;
        }

        private void openSerialPort()
        {
            try
            {
                serialPort1.PortName = cb_selectComPort.Text;
                serialPort1.BaudRate = Int32.Parse(cb_selectBaudRate.Text);
                serialPort1.DataBits = Int32.Parse(cb_selectDataBits.Text);
                serialPort1.Handshake = Handshake.None; // no flow control
                if (cb_selectParity.Text == "Even")
                {
                    serialPort1.Parity = Parity.Even;
                }
                else if (cb_selectParity.Text == "Odd")
                {
                    serialPort1.Parity = Parity.Odd;
                }
                else
                {
                    serialPort1.Parity = Parity.None;
                }

                if (cb_selectStopBits.Text == "0")
                {
                    serialPort1.StopBits = StopBits.None;
                }
                else
                {
                    serialPort1.StopBits = StopBits.One; //one stop bits
                }

                serialPort1.Open();
            }
            catch (Exception et)
            {
                MessageBox.Show("Serial Port canot be connected\n" + et.ToString());
            }
        }

        private void clearCharts()
        {
            foreach (var series in chart1_timeDomain.Series)
            {
                series.Points.Clear();
            }

            foreach (var series in chart1_frequencyDomain.Series)
            {
                series.Points.Clear();
            }
        }


        private void cb_selectComPort_Click(object sender, EventArgs e)
        {
            updateSerialDevices();
        }

        private double convertRawReading(string AdcData)
        {
            //raw to voltage
            int adcVal = Convert.ToInt32(AdcData);
            float tempAdcVal = (float)adcVal;
            float ExtVolData = ((tempAdcVal) * ((float)1.0)) / ((float)65536.0);


            //faction to int
            float Temp;
            Temp = ExtVolData;
            if (ExtVolData < 0) //in case adc is in Bipolar mode
            {
                Temp = -(ExtVolData);
            }

            int ExVolData1 = (((int)((Temp - (float)((int)Temp)) * (1000.0))));

            int ExVolData2 = (int)ExtVolData;

            string temp = ExVolData2.ToString() + "." + ExVolData1.ToString();

            double finalVal = Convert.ToDouble(temp);

            return finalVal;
        }

        public void plotSineWave()
        {
            double F = 500;
            double Fs = 1000;
            double Ts = 1 / Fs;
            List<double> _timeX = new List<double>();
            for (int i = 0; i < 100; i++)
            {
                _timeX.Add(i + Ts);
            }

            List<double> _sinWave = new List<double>();
            foreach (double _timeVal in _timeX)
            {
                _sinWave.Add(Math.Sin(2 * Math.PI * F * _timeVal));
            }

            //plot
            for (int i = 0; i < 100; i++)
            {
                chart1_timeDomain.Series["ch1_time"].Points.AddXY(_timeX.ElementAt(i), _sinWave.ElementAt(i));
            }

            //DFT


        }

        private void generateSineWaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            plotSineWave();
        }


        private void cb_samplingFrequency_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_samplingFrequency.Text == "4 kHz")
                {
                    if (serialPort1.IsOpen == true)
                    {
                        serialPort1.Write("f1@");
                    }

                }
                else if (cb_samplingFrequency.Text == "25 kHz")
                {
                    serialPort1.Write("f2@");
                }
                else if (cb_samplingFrequency.Text == "100 kHz")
                {
                    serialPort1.Write("f3@");
                }
                else if (cb_samplingFrequency.Text == "400 kHz")
                {
                    serialPort1.Write("f4@");
                }
                else if (cb_samplingFrequency.Text == "10 MHz")
                {
                    serialPort1.Write("f5@");
                }
            }
            catch (Exception ex)
            {

            }
           

        }


        /*
         *         private void chart1_timeDomain_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePoint = new Point(e.X, e.Y);

            chart1_timeDomain.ChartAreas[0].CursorX.SetCursorPixelPosition(mousePoint, true);
            chart1_timeDomain.ChartAreas[0].CursorY.SetCursorPixelPosition(mousePoint, true);

            lbl_cursorX.Text = e.X.ToString();
            lbl_cursorY.Text = e.Y.ToString();
        }
       */
        private double getCurrentSamplingFrequency()
        {
            double Fs = 0.0;
            if (cb_samplingFrequency.Text == "4 kHz")
            {
                Fs = 4000/2;
            }
            else if (cb_samplingFrequency.Text == "25 kHz")
            {
                Fs = 25000/2;
            }
            else if (cb_samplingFrequency.Text == "100 kHz")
            {
                //Fs = 100000/2;
                Fs = 51200;
            }
            else if (cb_samplingFrequency.Text == "400 kHz")
            {
                Fs = 400000/2;
            }
            else if (cb_samplingFrequency.Text == "10 MHz")
            {
                Fs = 10000000/2;
            }

            return Fs;
        }

        private void cb_bufferLength_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Write(("b" + cb_bufferLength.Text + "@"));
            }
            
        }

        private void tb_triggerConvertedVoltage_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (tb_rawVoltage.Text != String.Empty)
                {
                    tb_rawVoltage.Clear();
                    double temp = Convert.ToDouble(tb_triggerConvertedVoltage.Text);
                    temp = (temp * 65536) / (1.0);
                    tb_rawVoltage.Text = ((int)temp).ToString();
                }
            }
            catch (Exception ex)
            {
                tb_rawVoltage.Clear();
                tb_rawVoltage.Text = "3000";
            }
           
        }

        private void Cb_tiggerEdgeType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_tiggerEdgeType.Text == "Falling")
            {
                serialPort1.Write("z10@");
            }
            else if (cb_tiggerEdgeType.Text == "Rising")
            {
                if (serialPort1.IsOpen)
                {
                    serialPort1.Write("z01@");
                }
            }
            else
            {
                serialPort1.Write("z00@");
            }
        }

        private void Btn_changeTrigger_Click_1(object sender, EventArgs e)
        {
            double val = Convert.ToDouble(tb_rawVoltage.Text);
            if (val < 65536)
            {
                serialPort1.Write(("k" + tb_rawVoltage.Text + "@"));
            }
            else
            {
                MessageBox.Show("Can't trigger that value");
            }

            
        }

        private void Rb_startPlot_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Write("g1@");
            }
            catch (Exception ex)
            {
                
            }
        }

        private void Rb_stopPlot_CheckedChanged(object sender, EventArgs e)
        {
            //clearCharts();
            //serialPort1.Write("g0@");
        }

        private double rawReadingToVoltage(double rawData)
        {
            rawData = (rawData / ((double)4095));
            return rawData;
        }

        private void Cb_selectScale_SelectedIndexChanged(object sender, EventArgs e)
        {
            double max = 1;
            double min = 0;
            if (cb_selectScale.Text == "0-1")
            {
                min = 0;
                max = 1;
            }
            else if (cb_selectScale.Text == "0.5±(0.5/2)")
            {
                max = 0.5 + (0.5 / 2);
                min = 0.5 - (0.5 / 2);
            }
            else if (cb_selectScale.Text == "0.5±(0.5/8)")
            {
                max = 0.5 + (0.5 / 8);
                min = 0.5 - (0.5 / 8);
            }
            else if (cb_selectScale.Text == "0.5±(0.5/32)")
            {
                max = 0.5 + (0.5 / 32);
                min = 0.5 - (0.5 / 32);
            }
            else if (cb_selectScale.Text == "0.5±(0.5/100)")
            {
                max = 0.5 + (0.5 / 100);
                min = 0.5 - (0.5 / 100);
            }

            chart1_timeDomain.ChartAreas[0].AxisY.Minimum = min;
            chart1_timeDomain.ChartAreas[0].AxisY.Maximum = max;
        }

        private void Btn_changeDacFrequency_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                double dacFreq = 100000 / Convert.ToDouble(tb_dacFrequency.Text);
                int dFeq = (int)dacFreq;
                string cmd = "d" + dFeq.ToString() + "@";
                serialPort1.Write(cmd);
            }
            else
            {
                MessageBox.Show("Serial POrt NOt Connected");
            }
        }

        private void Cb_timeScale_SelectedIndexChanged(object sender, EventArgs e)
        {
            double max = chart1_timeDomain.ChartAreas[0].AxisX.Maximum;
            if (cb_timeScale.Text == "0.5")
            {
                max = max / 2;
            }
            else if (cb_timeScale.Text == "0.25")
            {
                max = max / 4;
            }
            else if (cb_timeScale.Text == "0.125")
            {
                max = max / 8;
            }
            else if (cb_timeScale.Text == "1")
            {
                max = Convert.ToDouble(cb_bufferLength.Text);
            }
            chart1_timeDomain.ChartAreas[0].AxisX.Maximum = max;
        }
    }
}