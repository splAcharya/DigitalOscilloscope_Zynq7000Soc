/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xscutimer.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "xsysmon.h"
#include "xstatus.h"
#include "xil_types.h"
#include "xil_assert.h"
#include <stdlib.h>
#include "xuartps_hw.h"
//#include "xgpio.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

/************************** Constant Definitions *****************************/

/*
 * The following constants map to the XPAR parameters created in the
 * xparameters.h file. They are only defined here such that a user can easily
 * change all the needed parameters in one place.
 */

#define TIMER_DEVICE_ID      XPAR_XSCUTIMER_0_DEVICE_ID
#define INTC_DEVICE_ID      XPAR_SCUGIC_SINGLE_DEVICE_ID
#define TIMER_IRPT_INTR      XPAR_SCUTIMER_INTR


#define DAC_ADDR XPAR_DAC_0_CUSTOM_DAC_BASEADDR



// More user definitions for readability in switch interrupt handler
#define enable_output 1  // SW0
#define ten_HZ 3  // SW1 and SW0
#define hundered_HZ 5  // SW2 and SW0
#define thousand_HZ 9  // SW3 and SW0
#define tenThousand_HZ 17  // SW4 and SW0
#define freq_not_selected 1



#define TIMER_LOAD_VALUE            70000//0xFFFF
#define BUFFER_MAX_SIZE               2048



#define TRIGGER_MAX_VOL               65536
#define TRIGGER_MIN_VOL               0

/**************************** Type Definitions *******************************/



/***************** Macros (Inline Functions) Definitions *********************/
#define SYSMON_DEVICE_ID XPAR_SYSMON_0_DEVICE_ID //ID of xadc_wiz_0
#define XSysMon_RawToExtVoltage(AdcData) \
((((float)(AdcData))*(1.0))/65536.0)  //(ADC 16bit result)/16/4096 = (ADC 16bit result)/65536
                              // voltage value = (ADC 16bit result)/65536 * 1Volt

static XSysMon SysMonInst; //a sysmon instance
static int SysMonFractionToInt(float FloatNum);   //fucntion that convert fraction into integer
void initializeArray(void);
char* extractPayload(char*buf, char*token1, char* token2);
static void changeTimerFrequency(int range,XScuTimer *TimerInstancePtr);

/************************** Function Prototypes ******************************/

int ScuTimerIntrExample(XScuGic *IntcInstancePtr, XScuTimer *TimerInstancePtr,
         u16 TimerDeviceId, u16 TimerIntrId);

static void TimerIntrHandler(void *CallBackRef);

static int TimerSetupIntrSystem(XScuGic *IntcInstancePtr,
            XScuTimer *TimerInstancePtr, u16 TimerIntrId);

static void TimerDisableIntrSystem(XScuGic *IntcInstancePtr, u16 TimerIntrId);

void changeDacFrequency(int cDiv);

/************************** Variable Definitions *****************************/
//XGpio Gpio; /* The Instance of the GPIO Driver */
XScuTimer TimerInstance;   /* Cortex A9 Scu Private Timer Instance */
XScuGic IntcInstance;      /* Interrupt Controller Instance */


int xStatus;
u32 ExtVolRawData, ExtVolRawData1;
float ExtVolData, ExtVolData1;
XSysMon_Config *SysMonConfigPtr;
XSysMon *SysMonInstPtr = &SysMonInst;

int toggle = 0;

int rawVoltage[BUFFER_MAX_SIZE];
int sampleCount = 0;
int TOTAL_SAMPLES = 32;


int sendWhenReady = 0;
int commandReceived = 0;
int commandPayload = 0;

int TRIGGER_EXACT = 3000;
int triggerEdge = 01;
int TRIGGER_RANGE = 25;

char REC_BUF[16];
int REC_BUF_POINTER = 0;
char *payLoad;

//dac
typedef struct
{
   u32 enable;
   u32 skipSamples;
   u32 clkDiv;

}DAC_ctrl;


DAC_ctrl *DAC_parameters = (DAC_ctrl *)DAC_ADDR;





//states
int state_1 = 0;
int state_2 = 0;

int main()
{


    init_platform();


    //----------------------------------------------------------------------- SysMon Initialize
    SysMonConfigPtr = XSysMon_LookupConfig(SYSMON_DEVICE_ID);
    if(SysMonConfigPtr == NULL) printf("LookupConfig FAILURE\n\r");

    xStatus = XSysMon_CfgInitialize(SysMonInstPtr, SysMonConfigPtr,SysMonConfigPtr->BaseAddress);
    if(XST_SUCCESS != xStatus) printf("CfgInitialize FAILED\r\n");

    //-----------------------------------------------------------------------------------------
    XSysMon_GetStatus(SysMonInstPtr); // Clear the old status



    int Status = ScuTimerIntrExample(&IntcInstance, &TimerInstance,TIMER_DEVICE_ID, TIMER_IRPT_INTR); //init timer

    //Status =  XGpio_Initialize(&Gpio, XPAR_GPIO_0_DEVICE_ID); //init dgpio
    //XGpio_SetDataDirection(&Gpio, 1,0);
    changeTimerFrequency(1000,&TimerInstance);
    initializeArray();

    //keep DAC initially off
    DAC_parameters->enable = 0;


    state_1 = 1;
    while(1)
    {

        // check for incoming data from GUI
        if(XUartPs_IsReceiveData(STDIN_BASEADDRESS))
        {
           char x = XUartPs_ReadReg(STDIN_BASEADDRESS, XUARTPS_FIFO_OFFSET);
           //xil_printf("%c",x);
           if(x == '@')
           {
              REC_BUF[REC_BUF_POINTER] = x;
              REC_BUF_POINTER = 0;

              //get opcode
              char menu = REC_BUF[0];

              //do operation based on commands
              switch(menu)
              {

                 // change sample size
                 case 'b':
                    payLoad = extractPayload(REC_BUF,"b","@"); //extract payload
                    int temp1 = atoi(payLoad); //change total sample limit
                    if( (temp1 <= BUFFER_MAX_SIZE) && (temp1 > 8) )
                    {
                       //TOTAL_SAMPLES = temp1;
                       commandReceived = 1;
                       commandPayload = temp1;
                    }
                    break;


                 //change sampling frequency
                 case 'f':
                    payLoad = extractPayload(REC_BUF,"f","@"); //extract payload
                    int temp0 = atoi(payLoad); //change total sample limit
                    changeTimerFrequency(temp0,&TimerInstance); //change frequency
                    break;


                 //change trigger point
                 case 'k':
                    payLoad = extractPayload(REC_BUF,"k","@"); //extract payload
                    int temp3 = atoi(payLoad); //change total sample limit
                    if( (temp3 <= TRIGGER_MAX_VOL) && (temp3 >= TRIGGER_MIN_VOL) )
                    {
                       TRIGGER_EXACT = temp3;
                       //commandReceived = 3;
                       //commandPayload = temp3;
                    }
                    break;


                  //change trigger edge
                 case 'z':
                        payLoad = extractPayload(REC_BUF,"z","@"); //extract payload
                        int temp4 = atoi(payLoad); //change total sample limit

                        if(temp4 == 10)
                        {
                           triggerEdge = temp4;
                           //commandPayload = temp4;
                        }
                        else if(temp4 == 1)
                        {
                           triggerEdge = temp4;
                           //commandPayload = temp4;
                        }
                        else if(temp4 == 0)
                        {
                           triggerEdge = temp4;
                           //commandPayload = temp4;
                        }

                        break;

                 //dac samples to skip
                 case 'd':
                     payLoad = extractPayload(REC_BUF,"d","@"); //extract payload
                     int temp5 = atoi(payLoad); //change total sample limit
                     changeDacFrequency(temp5);
                    break;



                 //send samples
                 case 'g':
                    sendWhenReady = 1;
                    break;
              }

              //clear buffer
              memset(REC_BUF,0,sizeof(REC_BUF));
           }
           else
           {
              REC_BUF[REC_BUF_POINTER] = x;
              REC_BUF_POINTER = REC_BUF_POINTER + 1;
           }

        }


        if(sendWhenReady == 1)
        {
           if(sampleCount == TOTAL_SAMPLES)
           {
              int i = 0;
              xil_printf("@");
              for(i =0; i<TOTAL_SAMPLES; i++)
              {
                 //ExtVolData = XSysMon_RawToExtVoltage(rawVoltage[i]);
                 //xil_printf("%0d.%03d",(int)ExtVolData,SysMonFractionToInt(ExtVolData));
                 xil_printf("%i,",(rawVoltage[i]>>4));
                 //xil_printf(",");

              }
              xil_printf("!");
              state_1 = 1;
              state_2 = 0;

              switch(commandReceived)
              {
                    case 1:
                       TOTAL_SAMPLES = commandPayload;
                       break;

                    case 2:
                       break;

                    case 3:
                       //TRIGGER_EXACT = commandPayload;
                       break;

                    case 4:
                       //triggerEdge = commandPayload;
                       break;

                    default:
                       break;
              }

              commandReceived = 0;
              commandPayload = 0;

              sampleCount = 0;
              sendWhenReady = 0;
           }
        }


    }


    cleanup_platform();
    return 0;
}


//----------------------------------------------------------------------------------------------
int SysMonFractionToInt(float FloatNum)
{
float Temp;
Temp = FloatNum;
if (FloatNum < 0) {      // in case ADC is in Bipolar Mode
Temp = -(FloatNum);
}
return( ((int)((Temp -(float)((int)Temp)) * (1000.0))));
}



/*****************************************************************************/
/**
*
* This function tests the functioning of the Cortex A9 Scu Private Timer driver
* and hardware using interrupts.
*
* @param   IntcInstancePtr is a pointer to the instance of XScuGic driver.
* @param   TimerInstancePtr is a pointer to the instance of XScuTimer
*      driver.
* @param   TimerDeviceId is the Device ID of the XScuTimer device.
* @param   TimerIntrId is the Interrupt Id of the XScuTimer device.
*
* @return   XST_SUCCESS if successful, otherwise XST_FAILURE.
*
* @note      None.
*
******************************************************************************/
int ScuTimerIntrExample(XScuGic *IntcInstancePtr, XScuTimer * TimerInstancePtr,
         u16 TimerDeviceId, u16 TimerIntrId)
{
   int Status;
   XScuTimer_Config *ConfigPtr;

   /*
    * Initialize the Scu Private Timer driver.
    */
   ConfigPtr = XScuTimer_LookupConfig(TimerDeviceId);

   /*
    * This is where the virtual address would be used, this example
    * uses physical address.
    */
   Status = XScuTimer_CfgInitialize(TimerInstancePtr, ConfigPtr,
               ConfigPtr->BaseAddr);
   if (Status != XST_SUCCESS) {
      return XST_FAILURE;
   }

   /*
    * Perform a self-test to ensure that the hardware was built correctly.
    */
   Status = XScuTimer_SelfTest(TimerInstancePtr);
   if (Status != XST_SUCCESS) {
      return XST_FAILURE;
   }

   /*
    * Connect the device to interrupt subsystem so that interrupts
    * can occur.
    */
   Status = TimerSetupIntrSystem(IntcInstancePtr,
               TimerInstancePtr, TimerIntrId);
   if (Status != XST_SUCCESS) {
      return XST_FAILURE;
   }

   /*
    * Enable Auto reload mode.
    */
   XScuTimer_EnableAutoReload(TimerInstancePtr);

   /*
    * Load the timer counter register.
    */
   XScuTimer_LoadTimer(TimerInstancePtr, TIMER_LOAD_VALUE);


   XScuTimer_SetPrescaler(TimerInstancePtr,255);

   /*
    * Start the timer counter and then wait for it
    * to timeout a number of times.
    */
   XScuTimer_Start(TimerInstancePtr);


   return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function sets up the interrupt system such that interrupts can occur
* for the device.
*
* @param   IntcInstancePtr is a pointer to the instance of XScuGic driver.
* @param   TimerInstancePtr is a pointer to the instance of XScuTimer
*      driver.
* @param   TimerIntrId is the Interrupt Id of the XScuTimer device.
*
* @return   XST_SUCCESS if successful, otherwise XST_FAILURE.
*
* @note      None.
*
******************************************************************************/
static int TimerSetupIntrSystem(XScuGic *IntcInstancePtr,
               XScuTimer *TimerInstancePtr, u16 TimerIntrId)
{
   int Status;


   XScuGic_Config *IntcConfig;

   /*
    * Initialize the interrupt controller driver so that it is ready to
    * use.
    */
   IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
   if (NULL == IntcConfig) {
      return XST_FAILURE;
   }

   Status = XScuGic_CfgInitialize(IntcInstancePtr, IntcConfig,
               IntcConfig->CpuBaseAddress);
   if (Status != XST_SUCCESS) {
      return XST_FAILURE;
   }


   Xil_ExceptionInit();



   /*
    * Connect the interrupt controller interrupt handler to the hardware
    * interrupt handling logic in the processor.
    */
   Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_IRQ_INT,
            (Xil_ExceptionHandler)XScuGic_InterruptHandler,
            IntcInstancePtr);


   /*
    * Connect the device driver handler that will be called when an
    * interrupt for the device occurs, the handler defined above performs
    * the specific interrupt processing for the device.
    */
   Status = XScuGic_Connect(IntcInstancePtr, TimerIntrId,
            (Xil_ExceptionHandler)TimerIntrHandler,
            (void *)TimerInstancePtr);
   if (Status != XST_SUCCESS) {
      return Status;
   }

   /*
    * Enable the interrupt for the device.
    */
   XScuGic_Enable(IntcInstancePtr, TimerIntrId);

   /*
    * Enable the timer interrupts for timer mode.
    */
   XScuTimer_EnableInterrupt(TimerInstancePtr);


   /*
    * Enable interrupts in the Processor.
    */
   Xil_ExceptionEnable();


   return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function is the Interrupt handler for the Timer interrupt of the
* Timer device. It is called on the expiration of the timer counter in
* interrupt context.
*
* @param   CallBackRef is a pointer to the callback function.
*
* @return   None.
*
* @note      None.
*
******************************************************************************/
static void TimerIntrHandler(void *CallBackRef)
{
   XScuTimer *TimerInstancePtr = (XScuTimer *) CallBackRef;
   //xil_printf("Int babay\n");
   if(sampleCount < TOTAL_SAMPLES)
   {
      if(state_1 == 1) //check for trigger range
      {
         //Read the external Vpn Data;
         rawVoltage[sampleCount] = XSysMon_GetAdcData(SysMonInstPtr,XSM_CH_VPVN);
         sampleCount = sampleCount + 1;

         if(sampleCount == 2)
         {

            if(triggerEdge == 01)
            {
               //rising edge
               if ( (rawVoltage[0] >= TRIGGER_EXACT) && (rawVoltage[0] <= (TRIGGER_EXACT + TRIGGER_RANGE) ) )
               {
                  if(rawVoltage[0] < rawVoltage[1])
                  {
                     state_1 = 0;
                     state_2 = 1;
                  }
                  else
                  {
                     sampleCount = 0;
                  }
               }
               else
               {
                  sampleCount = 0;
               }
            }
            else if(triggerEdge == 10)
            {
               //falling edge
               if ( (rawVoltage[0] <= TRIGGER_EXACT) && (rawVoltage[0] >= (TRIGGER_EXACT- TRIGGER_RANGE) ) )
               {
                  if(rawVoltage[0] > rawVoltage[1])
                  {
                     state_1 = 0;
                     state_2 = 1;
                  }
                  else
                  {
                     sampleCount = 0;
                  }
               }
               else
               {
                  sampleCount = 0;
               }
            }
            else
            {
               if( ( rawVoltage[0] >= TRIGGER_EXACT ) && (rawVoltage[0] <= (TRIGGER_EXACT + TRIGGER_RANGE ) ) )
               {
                  state_1 = 0;
                  state_2 = 1;
               }
               else if( (rawVoltage[0] <= TRIGGER_EXACT) && ( rawVoltage[0] >= (TRIGGER_EXACT - TRIGGER_RANGE ) ) )
               {
                  state_1 = 0;
                  state_2 = 1;
               }
            }
         }
         else
         {
            state_1 = 1;
            state_2 = 0;
         }

      }
      else if(state_2 == 1)
      {
         rawVoltage[sampleCount] = XSysMon_GetAdcData(SysMonInstPtr,XSM_CH_VPVN);
         sampleCount = sampleCount + 1;
      }
   }



   XScuTimer_ClearInterruptStatus(TimerInstancePtr);
}


/*****************************************************************************/
/**
*
* This function disables the interrupts that occur for the device.
*
* @param   IntcInstancePtr is the pointer to the instance of XScuGic
*      driver.
* @param   TimerIntrId is the Interrupt Id for the device.
*
* @return   None.
*
* @note      None.
*
******************************************************************************/
static void TimerDisableIntrSystem(XScuGic *IntcInstancePtr, u16 TimerIntrId)
{
   /*
    * Disconnect and disable the interrupt for the Timer.
    */
   XScuGic_Disconnect(IntcInstancePtr, TimerIntrId);
}


/******************************************************************
 * This fucntion changes the timerfrequency
 * @param range is the frequency range selector
 * @return none
*******************************************************************/
static void changeTimerFrequency(int range,XScuTimer *TimerInstancePtr)
{

	if(range == 1)
   {
      //4Khz
      XScuTimer_SetPrescaler(TimerInstancePtr,8); //change prescaler
      XScuTimer_LoadTimer(TimerInstancePtr, 18499); //load timer register
   }
   else if(range == 2)
   {
      //25Khz
      XScuTimer_SetPrescaler(TimerInstancePtr,8); //change prescaler
      XScuTimer_LoadTimer(TimerInstancePtr, 2959); //load timer register
   }
   else if(range == 3)
   {
      //100kHz
      XScuTimer_SetPrescaler(TimerInstancePtr,8); //change prescaler
      XScuTimer_LoadTimer(TimerInstancePtr, 739); //load timer register
   }
   else if(range == 4)
   {
      //400khz
      XScuTimer_SetPrescaler(TimerInstancePtr,8); //change prescaler
      XScuTimer_LoadTimer(TimerInstancePtr, 184); //load timer register
   }
   else if(range == 5)
   {
      //10MHz
      XScuTimer_SetPrescaler(TimerInstancePtr,8); //change prescaler
      XScuTimer_LoadTimer(TimerInstancePtr, 7); //load timer register
   }

}



void initializeArray(void)
{
   int i =0;
   for( i = 0; i < TOTAL_SAMPLES; i++)
   {
      rawVoltage[i] = 0;
   }
}


char* extractPayload(char*buf, char*token1, char* token2)
{
   char * delimiterFinder;
   delimiterFinder = strtok(buf, token1);
   delimiterFinder = strtok(delimiterFinder, token2);
   return delimiterFinder;
}


void changeDacFrequency(int cDiv)
{
    DAC_parameters->enable = 0;
    DAC_parameters->skipSamples = 1;
    DAC_parameters->clkDiv = cDiv;
    DAC_parameters->enable = 1;
}
